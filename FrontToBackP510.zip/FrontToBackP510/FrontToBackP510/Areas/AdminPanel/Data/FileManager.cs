﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;

namespace FrontToBackP510.Areas.AdminPanel.Data
{
    public static class FileManager
    {
        public static async Task<string> GenerateFileAsync(IFormFile file, string folderPath)
        {
            var imageName = $"{Guid.NewGuid()}-{file.FileName}";
            var path = Path.Combine(folderPath, imageName);

            using (var fileStream = new FileStream(path, FileMode.Create))
            {
                await file.CopyToAsync(fileStream);
            }

            return imageName;
        }

        public static void DeleteFile(string folderPath, string fileName)
        {
            var path = Path.Combine(folderPath, fileName);

            if (File.Exists(path))
            {
                File.Delete(path);
            }
        }
    }
}
