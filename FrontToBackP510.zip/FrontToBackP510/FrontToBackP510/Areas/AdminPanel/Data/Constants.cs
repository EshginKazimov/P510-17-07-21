﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FrontToBackP510.Areas.AdminPanel.Data
{
    public static class Constants
    {
        public static string ImageFolderPath = "";
    }
}
