﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FrontToBackP510.Data
{
    public static class RoleConstants
    {
        public const string AdminRole = "Admin";
        public const string MemberRole = "Member";
    }
}
