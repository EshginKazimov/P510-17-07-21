﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FrontToBackP510.Data;
using FrontToBackP510.Models;
using FrontToBackP510.ViewModels;
using Microsoft.AspNetCore.Identity;

namespace FrontToBackP510.Controllers
{
    public class AccountController : Controller
    {
        private readonly UserManager<User> _userManager;
        private readonly SignInManager<User> _signInManager;
        private readonly RoleManager<IdentityRole> _roleManager;

        public AccountController(UserManager<User> userManager, SignInManager<User> signInManager, RoleManager<IdentityRole> roleManager)
        {
            _userManager = userManager;
            _signInManager = signInManager;
            _roleManager = roleManager;
        }

        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login(LoginViewModel loginViewModel)
        {
            if (!ModelState.IsValid)
            {
                return View();
            }

            var existUser = await _userManager.FindByEmailAsync(loginViewModel.Email);
            if (existUser == null)
            {
                ModelState.AddModelError("", "Email or password is incorrect.");
                return View();
            }

            if (!existUser.IsActive)
            {
                ModelState.AddModelError("", "This user isn't active.");
                return View();
            }

            var signInResult = await _signInManager.PasswordSignInAsync(existUser, loginViewModel.Password, true, true);
            if (signInResult.IsLockedOut)
            {
                ModelState.AddModelError("", "Bu email block olunub.");
                return View();
            }
            
            if (!signInResult.Succeeded)
            {
                ModelState.AddModelError("", "Email or password is incorrect.");
                return View();
            }

            return RedirectToAction("Index", "Home");
        }

        public IActionResult Register()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Register(RegisterViewModel registerViewModel)
        {
            if (!ModelState.IsValid)
            {
                return View();
            }

            var existUser = await _userManager.FindByNameAsync(registerViewModel.Username);
            if (existUser != null)
            {
                ModelState.AddModelError("Username", "Bele adda user var.");
                return View();
            }

            var user = new User
            {
                UserName = registerViewModel.Username,
                FullName = registerViewModel.Fullname,
                Email = registerViewModel.Email
            };

            var result = await _userManager.CreateAsync(user, registerViewModel.Password);
            if (!result.Succeeded)
            {
                foreach (var error in result.Errors)
                {
                    ModelState.AddModelError("", error.Description);
                }

                return View();
            }

            await _userManager.AddToRoleAsync(user, RoleConstants.MemberRole);
            await _signInManager.SignInAsync(user, true);

            return RedirectToAction("Index", "Home");
        }

        public async Task<IActionResult> Logout()
        {
            await _signInManager.SignOutAsync();

            return RedirectToAction("Index", "Home");
        }

        #region Roles

        //public async Task<IActionResult> AddRoles()
        //{
        //    if (!await _roleManager.RoleExistsAsync(RoleConstants.AdminRole))
        //        await _roleManager.CreateAsync(new IdentityRole(RoleConstants.AdminRole));

        //    if (!await _roleManager.RoleExistsAsync(RoleConstants.MemberRole))
        //        await _roleManager.CreateAsync(new IdentityRole(RoleConstants.MemberRole));

        //    return Ok("Success");
        //}

        #endregion
    }
}
