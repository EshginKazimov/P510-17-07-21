﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FrontToBackP510.DataAccessLayer;
using FrontToBackP510.Models;
using FrontToBackP510.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;

namespace FrontToBackP510.Controllers
{
    public class HomeController : Controller
    {
        private readonly AppDbContext _dbContext;
        private readonly int _productsCount;

        public HomeController(AppDbContext dbContext)
        {
            _dbContext = dbContext;
            _productsCount = _dbContext.Products.Count();
        }

        public async Task<IActionResult> Index()
        {
            //HttpContext.Session.SetString("group", "Hello P510!");
            //Response.Cookies.Append("group", "Bye P510!!!", new CookieOptions{MaxAge = TimeSpan.FromDays(30)});

            ViewBag.ProductsCount = _productsCount;

            var slider = await _dbContext.Sliders.FirstOrDefaultAsync();
            var sliderImages = await _dbContext.SliderImages.ToListAsync();
            var categories = await _dbContext.Categories.ToListAsync();
            //var products = await _dbContext.Products.Include(x => x.Category).Take(8).ToListAsync();
            var about = await _dbContext.Abouts.FirstOrDefaultAsync();
            var aboutPolicies = await _dbContext.AboutPolicies.ToListAsync();
            var blog = await _dbContext.Blogs.FirstOrDefaultAsync();
            var blogItems = await _dbContext.BlogItems.OrderByDescending(x => x.Id).Take(3).ToListAsync();

            var homeViewModel = new HomeViewModel
            {
                Slider = slider,
                SliderImages = sliderImages,
                Categories = categories,
                //Products = products,
                About = about,
                AboutPolicies = aboutPolicies,
                Blog = blog,
                BlogItems = blogItems
            };

            return View(homeViewModel);
        }

        public async Task<IActionResult> AddToBasket(int? id)
        {
            if (id == null)
                return NotFound();

            var product = await _dbContext.Products.FindAsync(id);
            if (product == null)
                return NotFound();

            List<BasketViewModel> basketList;
            var existBasketCookie = Request.Cookies["basket"];
            if (string.IsNullOrEmpty(existBasketCookie))
            {
                basketList = new List<BasketViewModel>();
            }
            else
            {
                basketList = JsonConvert.DeserializeObject<List<BasketViewModel>>(existBasketCookie);
            }

            var existProductInBasket = basketList.FirstOrDefault(x => x.Id == id);
            if (existProductInBasket == null)
            {
                basketList.Add(new BasketViewModel
                {
                    Id = product.Id
                });
            }
            else
            {
                existProductInBasket.Count++;
            }

            var basketCookie = JsonConvert.SerializeObject(basketList);
            Response.Cookies.Append("basket", basketCookie);

            return RedirectToAction("Index");
        }

        public async Task<IActionResult> Basket()
        {
            //var session = HttpContext.Session.GetString("group");
            //var cookie = Request.Cookies["group"];
            //return Content(session + " - " + cookie);

            var basketCookie = Request.Cookies["basket"];
            if (string.IsNullOrEmpty(basketCookie))
                return Content("No data found in basket.");

            var products = JsonConvert.DeserializeObject<List<BasketViewModel>>(basketCookie);
            var result = new List<BasketViewModel>();
            foreach (var product in products)
            {
                var dbProduct = await _dbContext.Products.Include(x => x.Category).FirstOrDefaultAsync(x => x.Id == product.Id);
                if (dbProduct == null)
                    continue;

                product.Name = dbProduct.Name;
                product.Price = dbProduct.Price;
                product.Image = dbProduct.Image;
                product.CategoryId = dbProduct.CategoryId;
                product.Category = dbProduct.Category;
                
                result.Add(product);
            }

            basketCookie = JsonConvert.SerializeObject(result, new JsonSerializerSettings{ReferenceLoopHandling = ReferenceLoopHandling.Ignore});
            Response.Cookies.Append("basket", basketCookie);

            return Json(result);
        }

        public IActionResult Load(int skip)
        {
            if (skip >= _productsCount)
            {
                return BadRequest();
            }

            var products = _dbContext.Products.Include(x => x.Category).Skip(skip).Take(8).ToList();

            return PartialView("_ProductsPartial", products);

            #region Old partial

            //var products = _dbContext.Products.Include(x => x.Category).Skip(8).Take(8).ToList();

            //return Json(products);

            #endregion
        }

        public async Task<IActionResult> Search(string searchText)
        {
            var products = await _dbContext.Products.Where(x => x.Name.Contains(searchText)).ToListAsync();

            return PartialView("_SearchProductPartial", products);
        }
    }
}
